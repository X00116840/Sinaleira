package android.support.v4.os;

import android.os.Trace;

class TraceJellybeanMR2
{
  public static void beginSection(String paramString)
  {
    Trace.beginSection(paramString);
  }
  
  public static void endSection() {}
}


/* Location:           D:\workspace\Sinaleira\RecoveringPelicross\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.os.TraceJellybeanMR2
 * JD-Core Version:    0.7.0.1
 */