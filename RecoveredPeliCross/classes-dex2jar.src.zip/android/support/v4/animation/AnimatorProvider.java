package android.support.v4.animation;

abstract interface AnimatorProvider
{
  public abstract ValueAnimatorCompat emptyValueAnimator();
}


/* Location:           D:\workspace\Sinaleira\RecoveringPelicross\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.animation.AnimatorProvider
 * JD-Core Version:    0.7.0.1
 */