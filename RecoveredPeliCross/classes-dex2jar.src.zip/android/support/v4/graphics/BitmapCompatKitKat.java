package android.support.v4.graphics;

import android.graphics.Bitmap;

class BitmapCompatKitKat
{
  static int getAllocationByteCount(Bitmap paramBitmap)
  {
    return paramBitmap.getAllocationByteCount();
  }
}


/* Location:           D:\workspace\Sinaleira\RecoveringPelicross\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.graphics.BitmapCompatKitKat
 * JD-Core Version:    0.7.0.1
 */