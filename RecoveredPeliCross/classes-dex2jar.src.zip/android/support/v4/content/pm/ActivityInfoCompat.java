package android.support.v4.content.pm;

public class ActivityInfoCompat
{
  public static final int CONFIG_UI_MODE = 512;
}


/* Location:           D:\workspace\Sinaleira\RecoveringPelicross\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     android.support.v4.content.pm.ActivityInfoCompat
 * JD-Core Version:    0.7.0.1
 */