package com.example.pelicancross;

import android.os.Bundle;

public class Instructions
  extends MainActivity
{
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903042);
  }
}


/* Location:           D:\workspace\Sinaleira\RecoveringPelicross\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.example.pelicancross.Instructions
 * JD-Core Version:    0.7.0.1
 */