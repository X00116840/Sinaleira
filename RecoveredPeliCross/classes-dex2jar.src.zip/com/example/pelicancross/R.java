package com.example.pelicancross;

public final class R
{
  public static final class array
  {
    public static final int androidcolors = 2131034112;
  }
  
  public static final class attr {}
  
  public static final class color
  {
    public static final int blue = 2130968576;
    public static final int darkblue = 2130968581;
    public static final int darkgreen = 2130968583;
    public static final int darkorange = 2130968584;
    public static final int darkpurple = 2130968582;
    public static final int darkred = 2130968585;
    public static final int green = 2130968578;
    public static final int orange = 2130968579;
    public static final int purple = 2130968577;
    public static final int red = 2130968580;
  }
  
  public static final class dimen
  {
    public static final int activity_horizontal_margin = 2131099648;
    public static final int activity_vertical_margin = 2131099649;
  }
  
  public static final class drawable
  {
    public static final int amber_on = 2130837504;
    public static final int amberlight = 2130837505;
    public static final int button_background = 2130837506;
    public static final int green = 2130837507;
    public static final int green_on = 2130837508;
    public static final int greenlight = 2130837509;
    public static final int ic_launcher = 2130837510;
    public static final int lightoff = 2130837511;
    public static final int pelimad = 2130837512;
    public static final int red = 2130837513;
    public static final int red_on = 2130837514;
    public static final int redlight = 2130837515;
  }
  
  public static final class id
  {
    public static final int LinearLayout1 = 2131427344;
    public static final int action_settings = 2131427352;
    public static final int amber_lgt = 2131427331;
    public static final int buttonClearRank = 2131427345;
    public static final int buttonExitApp = 2131427343;
    public static final int buttonInstructions = 2131427342;
    public static final int buttonNext = 2131427338;
    public static final int buttonPlay = 2131427340;
    public static final int buttonPlayAgain = 2131427346;
    public static final int buttonRank = 2131427341;
    public static final int cancel = 2131427329;
    public static final int container = 2131427339;
    public static final int currentX = 2131427333;
    public static final int currentY = 2131427334;
    public static final int currentZ = 2131427335;
    public static final int currentspeed_db = 2131427348;
    public static final int green_lgt = 2131427332;
    public static final int playerName = 2131427337;
    public static final int ratingBar = 2131427351;
    public static final int red_lgt = 2131427330;
    public static final int speed_db = 2131427350;
    public static final int textView1 = 2131427336;
    public static final int textView5 = 2131427349;
    public static final int timer_label = 2131427328;
    public static final int timestamp = 2131427347;
  }
  
  public static final class integer
  {
    public static final int Stars = 2131165184;
  }
  
  public static final class layout
  {
    public static final int accelerometer = 2130903040;
    public static final int database_entry = 2130903041;
    public static final int instructions = 2130903042;
    public static final int main_menu = 2130903043;
    public static final int rank = 2130903044;
    public static final int traffic_lights = 2130903045;
    public static final int warning = 2130903046;
  }
  
  public static final class menu
  {
    public static final int main = 2131361792;
  }
  
  public static final class string
  {
    public static final int action_settings = 2131230721;
    public static final int app_name = 2131230720;
    public static final int b_speed = 2131230729;
    public static final int button_instructions = 2131230724;
    public static final int button_next = 2131230730;
    public static final int button_play = 2131230722;
    public static final int button_rank = 2131230723;
    public static final int champion = 2131230728;
    public static final int clear_r = 2131230733;
    public static final int exit = 2131230737;
    public static final int game_ID = 2131230732;
    public static final int go = 2131230734;
    public static final int inst_text = 2131230738;
    public static final int name = 2131230725;
    public static final int play_again = 2131230735;
    public static final int stars = 2131230726;
    public static final int stop = 2131230736;
    public static final int warning1 = 2131230731;
    public static final int y_speed = 2131230727;
  }
  
  public static final class style
  {
    public static final int AppBaseTheme = 2131296256;
    public static final int AppTheme = 2131296257;
    public static final int styleName = 2131296258;
  }
}


/* Location:           D:\workspace\Sinaleira\RecoveringPelicross\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.example.pelicancross.R
 * JD-Core Version:    0.7.0.1
 */