package com.example.pelicancross;

public final class BuildConfig
{
  public static final boolean DEBUG = true;
}


/* Location:           D:\workspace\Sinaleira\RecoveringPelicross\dex2jar-0.0.9.15\classes-dex2jar.jar
 * Qualified Name:     com.example.pelicancross.BuildConfig
 * JD-Core Version:    0.7.0.1
 */